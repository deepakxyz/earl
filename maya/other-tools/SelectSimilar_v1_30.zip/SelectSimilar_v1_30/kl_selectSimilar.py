import maya.cmds as mc
import maya.mel as mel


def kl_selectSimilar():
    
        #  If objects selected then try to select all the same objects in the scene
    if mc.filterExpand(sm=12):
            # empty array - adding all final similar objects.
        similarObjects = []
        
            # get selected object - base object to which you want to select all other similar ones
        selectedMainObj = mc.ls (mc.filterExpand(sm=12), sl=True, l=True, tr=True)
            
            # get all meshes in the scene (transforms)
        allSceneMeshes = mc.filterExpand (mc.ls (l=True, typ = 'transform'), sm=12)
        
        for i in range(len(selectedMainObj)):
            
            selVertices = mc.polyEvaluate (selectedMainObj[i], vertex=True)         # get vertices count of base objects
            getArea = mc.polyEvaluate (selectedMainObj[i], worldArea=True)          # get world Area (volume) 
            selecArea = round (getArea, 2)                                          # round worldArea numbers to 2 decimanls otherwise it will no select objects
            
            for j in range(len(allSceneMeshes)):
                toCompareVertices = mc.polyEvaluate (allSceneMeshes[j], vertex=True)
                toGetArea = mc.polyEvaluate (allSceneMeshes[j], worldArea=True)
                toCompareArea = round (toGetArea, 2)
                
                if selVertices == toCompareVertices and selecArea == toCompareArea:
                    similarObjects.append(allSceneMeshes[j])
          
        mc.select (similarObjects, r=True)

        #  If components selected then use Maya defaul select similar tool.
    if mc.filterExpand(sm=(31, 32, 34)):
        mel.eval ("SelectSimilar;")



def kl_selectSimilarTopo():
    
    selectedObj = mc.ls (mc.filterExpand(sm=12), sl=True, l=True, tr=True)
    allSceneMeshesTopo = mc.filterExpand (mc.ls (l=True, typ = 'transform'), sm=12)
    
    similarObjectsTopo = []
    
    for eachS in selectedObj:
        for t in range(len(allSceneMeshesTopo)):
            meshCheck = mc.polyCompare (eachS, allSceneMeshesTopo[t], fd=True, uv=True)
            
            if meshCheck == 0:
                similarObjectsTopo.append(allSceneMeshesTopo[t])
                
    mc.select (similarObjectsTopo, r=True)

        

        
        
        