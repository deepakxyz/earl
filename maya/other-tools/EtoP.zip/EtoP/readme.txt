Edges to Pipe 2.0

Update: Automatic UV Generation

How to Install:
1. Move "EtoP.mel" file to "C:\Users\"user name"\Documents\maya\"maya version"\prefs\scripts"
2. If Maya is running, restart it
3. In Script Editor copy/past command: source "EtoP.mel";
4. File - Save Script to Shelf
5. Run Script